Penly v0.8.0 local test build. Read UPGRADE-INSTRUCTIONS.txt. Never replace data/db.json.
